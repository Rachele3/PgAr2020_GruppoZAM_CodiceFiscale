package it.progettoArnaldo.esercizi.codiceFiscale;

import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

public class OutPutUtils {
	
	public static void xmleWrite(ArrayList <Person> persone, ArrayList <String> codiciSpaiati, ArrayList <String> codiciSbagliati){
		
		XMLOutputFactory xmlof = null;
		XMLStreamWriter xmlw = null;
		try {
			xmlof = XMLOutputFactory.newInstance();
			xmlw = xmlof.createXMLStreamWriter(new FileOutputStream("output.xml"), "utf-8");
			xmlw.writeStartDocument("utf-8", "1.0");
			xmlw.writeStartElement("persone");
			xmlw.writeAttribute("numero", Integer.toString(persone.size()));
			for(int i=0;i<persone.size();i++) {
				xmlw.writeStartElement("persona");
				xmlw.writeAttribute("id", Integer.toString(i));
				xmlw.writeStartElement("nome");
				xmlw.writeCharacters(persone.get(i).getNome());
				xmlw.writeEndElement();
				xmlw.writeStartElement("cognome");
				xmlw.writeCharacters(persone.get(i).getCognome());
				xmlw.writeEndElement();
				xmlw.writeStartElement("sesso");
				String gender;
				if(persone.get(i).getSesso()==0)
					gender="M";
				else gender="F";
				xmlw.writeCharacters(gender);
				xmlw.writeEndElement();
				xmlw.writeStartElement("comune_nascita");
				xmlw.writeCharacters(persone.get(i).getComune());
				xmlw.writeEndElement();
				xmlw.writeStartElement("codice_fiscale");
				xmlw.writeCharacters(persone.get(i).getCodiceFiscale());
				xmlw.writeEndElement();
				xmlw.writeEndElement();
			}
			xmlw.writeEndElement();
			xmlw.writeStartElement("codici");
			xmlw.writeStartElement("invalidi");
			xmlw.writeAttribute("numero", Integer.toString(codiciSbagliati.size()));
			for(int i=0;i<codiciSbagliati.size();i++) {
				xmlw.writeStartElement("codice");
				xmlw.writeCharacters(codiciSbagliati.get(i));
				xmlw.writeEndElement();
			}
			xmlw.writeEndElement();
			xmlw.writeStartElement("spaiati");
			xmlw.writeAttribute("numero", Integer.toString(codiciSpaiati.size()));
			for(int i=0;i<codiciSpaiati.size();i++) {
				xmlw.writeStartElement("codice");
				xmlw.writeCharacters(codiciSpaiati.get(i));
				xmlw.writeEndElement();
			}
			xmlw.writeEndElement();
			xmlw.writeEndElement();
			xmlw.writeEndDocument();
			xmlw.flush();
			xmlw.close();
			} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del writer:");
			System.out.println(e.getMessage());
			}
	}
}
