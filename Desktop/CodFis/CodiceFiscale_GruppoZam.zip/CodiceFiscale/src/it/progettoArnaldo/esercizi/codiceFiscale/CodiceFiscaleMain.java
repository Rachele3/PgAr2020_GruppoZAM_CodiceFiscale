package it.progettoArnaldo.esercizi.codiceFiscale;

import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

public class CodiceFiscaleMain {
	

	public static void main(String[] args) {
		
		ArrayList <Person> persone= new ArrayList<Person>();
		ArrayList <String> codiciSpaiati= new ArrayList<String>();
		ArrayList <String> codiciSbagliati= new ArrayList <String>();
		ArrayList <String> codiciSpaiatiFinal= new ArrayList <String>();
		persone=XmlUtilsInput.xmlPersone();
		for(int i=0;i<persone.size(); i++) {
				persone.get(i).addCode();
				if(XmlUtilsInput.sameCode(persone.get(i).getCodiceFiscale())==false) {
					codiciSpaiati.add(persone.get(i).getCodiceFiscale());
				}
				persone.get(i).thereIsCode();
		}
		
		for(int i=0;i<codiciSpaiati.size();i++) {
			if(CodiceFiscale.wrong(codiciSpaiati.get(i))) {
				codiciSpaiatiFinal.add(codiciSpaiati.get(i));
			}
			else codiciSbagliati.add(codiciSpaiati.get(i));
			
		}
		OutPutUtils.xmleWrite(persone, codiciSpaiatiFinal, codiciSbagliati);
	}
		
}
