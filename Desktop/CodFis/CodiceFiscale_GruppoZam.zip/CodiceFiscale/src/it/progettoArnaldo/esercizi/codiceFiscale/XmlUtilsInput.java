package it.progettoArnaldo.esercizi.codiceFiscale;

import java.io.FileInputStream;
import java.util.ArrayList;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

public class XmlUtilsInput {
	private static final String NOT_FOUND = "not found";

	
	
	public static ArrayList<Person> xmlPersone(){
		
		ArrayList <Person> persone=new ArrayList<Person>();
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		
		try{
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader("inputPersone.xml", new FileInputStream("inputPersone.xml"));
			while (xmlr.hasNext()) { // continua a leggere finch� ha eventi a disposizione
				switch (xmlr.getEventType()) { // switch sul tipo di evento
				case XMLStreamConstants.START_ELEMENT: // inizio di un elemento: stampa il nome del tag e i suoi attributi
				if(xmlr.getLocalName().equalsIgnoreCase("persona")) {
					int count=1;
					String nome=null;
					String cognome=null;
					String dataNascita=null;
					String comune=null;
					int sesso=0;
					String codiceFiscale=null;
						while (xmlr.hasNext() && count<=5) { // continua a leggere finch� ha eventi a disposizione
							switch (xmlr.getEventType()) { // switch sul tipo di evento
							case XMLStreamConstants.CHARACTERS: // content all�interno di un elemento: stampa il testo
							if (xmlr.getText().trim().length() > 0) { // controlla se il testo non contiene solo spazi
								
								switch(count) {
								case 0:
									break;
								case 1:
									nome=xmlr.getText();
									break;
								case 2:
									cognome=xmlr.getText();
									break;
								case 3:
									if(xmlr.getText().equalsIgnoreCase("f")) {
										sesso=1;
									}
									else sesso=0;
									break;
								case 4:
									comune=xmlr.getText();
									break;
								case 5:
									dataNascita=xmlr.getText();
									break;
								}
								count++;
							}
							break;
							}
							xmlr.next();
						}
						Person persona= new Person(nome, cognome, dataNascita, sesso, comune, codiceFiscale);
						persone.add(persona);
				}
				break;
				}
				xmlr.next();
				}
		
			}catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
			}
		return persone;
	}
	
	public static String codiceComune(String comune) {
		String codice=NOT_FOUND;
		boolean find=false;
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		try{
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader("comuni.xml", new FileInputStream("comuni.xml"));
			while (xmlr.hasNext() && find==false) { // continua a leggere finch� ha eventi a disposizione
				switch (xmlr.getEventType()) {// switch sul tipo di evento
				case XMLStreamConstants.START_ELEMENT:
						if(xmlr.getLocalName().equalsIgnoreCase("comune")) {
							int count=0;
							boolean sameComune=false;
							while(xmlr.hasNext() && count<2) {
								switch(xmlr.getEventType()) {
								case XMLStreamConstants.CHARACTERS :
									if (xmlr.getText().trim().length() > 0) {
										if(xmlr.getText().equalsIgnoreCase(comune)) {
											sameComune=true;
										}
										if(sameComune) {
										codice=xmlr.getText();
										find=true;
										}
										count++;
									}
									break;
								}
								xmlr.next();
							}
						}
				}
				xmlr.next();
			}
		}catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
			}
		return codice;
	}
	
	public static boolean sameCode(String codiceFiscale) {
		boolean found=false;
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		try{
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader("codiciFiscali.xml", new FileInputStream("codiciFiscali.xml"));
			while (xmlr.hasNext() && found==false) { 
				switch (xmlr.getEventType()) {
				case XMLStreamConstants.CHARACTERS:
					if(xmlr.getText().trim().length()>0) {
						if(xmlr.getText().equalsIgnoreCase(codiceFiscale)) {
							found=true;
						}
					}
				}
				xmlr.next();
			}
		}catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
			}
		return found;
	}
	
	public static ArrayList <String> codeWrong(){
		ArrayList <String> codes= new ArrayList <String>();
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		try{
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader("codiciFiscali.xml", new FileInputStream("codiciFiscali.xml"));
			while (xmlr.hasNext()) { 
				switch (xmlr.getEventType()) {
				case XMLStreamConstants.CHARACTERS:
					if(xmlr.getText().trim().length()>0) {
						if(CodiceFiscale.wrong(xmlr.getText())) {
							codes.add(xmlr.getText());
						}
					}
				}
				xmlr.next();
			}
		}catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
			}
		return codes;
	}
	
	public static boolean goodCodeComune(String codeComune) {
		boolean exist=false;
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		try{
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader("comuni.xml", new FileInputStream("comuni.xml"));
			while (xmlr.hasNext() && exist==false) { // continua a leggere finch� ha eventi a disposizione
				switch (xmlr.getEventType()) {// switch sul tipo di evento
				case XMLStreamConstants.START_ELEMENT:
						if(xmlr.getLocalName().equalsIgnoreCase("comune")) {
							int count=0;
							while(xmlr.hasNext() && count<2) {
								switch(xmlr.getEventType()) {
								case XMLStreamConstants.CHARACTERS :
									if (xmlr.getText().trim().length() > 0) {
										if(xmlr.getText().equalsIgnoreCase(codeComune)) {
											exist=true;
										}
										count++;
									}
									break;
								}
								xmlr.next();
							}
						}
				}
				xmlr.next();
			}
		}catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
			}
		return exist;
	}
	
}
