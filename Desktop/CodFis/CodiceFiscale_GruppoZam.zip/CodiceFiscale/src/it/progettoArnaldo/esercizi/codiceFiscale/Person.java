package it.progettoArnaldo.esercizi.codiceFiscale;

public class Person {
	private static final String ABSENT = "ASSENTE";
	private String nome;
	private String cognome;
	private String dataNascita;
	private int sesso;
	private String comune;
	private String codiceFiscale;
	

	public Person(String _nome, String _cognome, String _dataNascita, int _sesso, String _comune, String _codiceFiscale) {
		nome=_nome;
		cognome=_cognome;
		dataNascita=_dataNascita;
		sesso=_sesso;
		comune=_comune;
		codiceFiscale=_codiceFiscale;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}

	public int getSesso() {
		return sesso;
	}

	public void setSesso(int sesso) {
		this.sesso = sesso;
	}

	public String getComune() {
		return comune;
	}

	public void setComune(String comune) {
		this.comune = comune;
	}

	public String getCodiceFiscale() {
		return codiceFiscale;
	}

	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	
	public void addCode() {
		this.codiceFiscale=CodiceFiscale.calcolaCodiceFiscale(this);
	}
	public void thereIsCode() {
		boolean found=XmlUtilsInput.sameCode(this.codiceFiscale);
		if(found==false) {
			this.codiceFiscale=ABSENT;
		}
	}
}
