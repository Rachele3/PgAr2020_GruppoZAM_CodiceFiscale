package it.progettoArnaldo.esercizi.codiceFiscale;


public class CodiceFiscale {
	

	public static String calcolaCodiceFiscale(Person p) 
	{
		String codFis = "";
		
		String cognomecf = p.getCognome().toUpperCase();
		String nomecf = p.getNome().toUpperCase();
		String dataNascitacf = p.getDataNascita();
		String correttoComuneNascita = p.getComune().toUpperCase();
		
		
		// COGNOME
		/* calcolo prime 3 lettere */
		int cont = 0;
				
		/* caso cognome minore di 3 lettere */
		if (cognomecf.length() < 3) 
		{
			codFis = codFis + cognomecf;
			
			while (codFis.length() < 3) 
				codFis = codFis + "X";
			
			cont = 3;
		}
				
		/* caso normale */
		for (int i = 0; i < cognomecf.length(); i++) 
		{
			if (cont == 3) 
			break;
					
			if (cognomecf.charAt(i) != 'A' && cognomecf.charAt(i) != 'E' && cognomecf.charAt(i) != 'I' && 
					cognomecf.charAt(i) != 'O' && cognomecf.charAt(i) != 'U') 
			{
				codFis = codFis + Character.toString(cognomecf.charAt(i));
				cont++;
			}
		}
				
				
		/* nel caso ci siano meno di 3 consonanti*/
		while (cont < 3) 
		{
			for (int i = 0; i < cognomecf.length(); i++) 
			{
				if (cont == 3) 
					break;
				
				if (cognomecf.charAt(i) == 'A' || cognomecf.charAt(i) == 'E' || cognomecf.charAt(i) == 'I' || 
					cognomecf.charAt(i) == 'O' || cognomecf.charAt(i) == 'U') 
				{
					codFis = codFis + Character.toString(cognomecf.charAt(i));
					cont++;
				}
			}
		}
	
		
		// NOME
		/* lettere nome */
		cont = 0;
		
		/* caso nome minore di 3 lettere */
		if (nomecf.length() < 3) 
		{
			codFis = codFis + nomecf;
			
			while (codFis.length() < 6) 
				codFis = codFis + "X";
			
			cont = 3;
		}
		
		/*caso normale*/
		for (int i = 0; i < nomecf.length(); i++) 
		{
			if (cont == 3) 
				break;
			
			if (nomecf.charAt(i) != 'A' && nomecf.charAt(i) != 'E' && nomecf.charAt(i) != 'I' && 
				nomecf.charAt(i) != 'O' && nomecf.charAt(i) != 'U') 
			{
				codFis = codFis + Character.toString(nomecf.charAt(i));
				cont++;
			}
		}
		
		
		/* nel caso ci siano meno di 3 consonanti*/
		while (cont < 3) 
		{
			for (int i = 0; i < nomecf.length(); i++) 
			{
				if (cont == 3) 
					break;
				
				if (nomecf.charAt(i) == 'A' || nomecf.charAt(i) == 'E' || nomecf.charAt(i) == 'I' || 
					nomecf.charAt(i) == 'O' || nomecf.charAt(i) == 'U') 
				{
					codFis = codFis + Character.toString(nomecf.charAt(i));
					cont++;
				}
			}
		}
		
		
		//DATA
		/* Anno */
		codFis = codFis + dataNascitacf.substring(2, 4);
		
		/* Mese */
		int mese = 0;
	
		mese = Integer.parseInt(dataNascitacf.substring(5, 7));
		
		switch (mese) 
		{
			case 01: 
				codFis = codFis + "A";
				break;
			
			case 02:
				codFis = codFis + "B";
				break;
			
			case 03:
				codFis = codFis + "C";
				break;
			
			case 4:
				codFis = codFis + "D";
				break;
			
			case 5: 
				codFis = codFis + "E";
				break;
			
			case 6:
				codFis = codFis + "H";
				break;
			
			case 7:
				codFis = codFis + "L";
				break;
			
			case 8: 
				codFis = codFis + "M";
				break;
			
			case 9: 
				codFis = codFis + "P";
				break;
			
			case 10:
				codFis = codFis + "R";
				break;
				
			case 11:
				codFis = codFis + "S";
				break;
				
			case 12: 
				codFis = codFis + "T";
				break;
		}
		
		/* Giorno */
		int giorno = 0;
		
		giorno = Integer.parseInt(dataNascitacf.substring(8, 10));
		
		// GENERE
		// se maschio
		if (p.getSesso() == 0)
        {
            if(giorno < 10)
                codFis = codFis + "0" + giorno;
            if (giorno >= 10)
                codFis = codFis + giorno;
        }
		
		//se femmina
		else if (p.getSesso() == 1)
		{
			giorno = giorno + 40;
			codFis = codFis + Integer.toString(giorno);
		}
		
		
		
		// COMUNE DI NASCITA
		String temp=XmlUtilsInput.codiceComune(p.getComune());
			codFis = codFis + temp.toUpperCase();
		
		
		// ULTIMA LETTERA: Carattere di controllo
		int sommaPari = 0;
		
		for (int i = 1; i <= 13; i = i + 2) 
		{
			switch (codFis.charAt(i)) 
			{
				case '0':
					sommaPari = sommaPari + 0;
					break;
				
				case '1': 
					sommaPari = sommaPari + 1;
					break;
				
				case '2': 
					sommaPari = sommaPari + 2;
					break;
				
				case '3': 
					sommaPari = sommaPari + 3;
					break;
				
				case '4': 
					sommaPari = sommaPari + 4;
					break;
				
				case '5': 
					sommaPari = sommaPari + 5;
					break;
				
				case '6': 
					sommaPari = sommaPari + 6;
					break;
					
				case '7': 
					sommaPari = sommaPari + 7;
					break;
					
				case '8': 
					sommaPari = sommaPari + 8;
					break;
					
				case '9': 
					sommaPari = sommaPari + 9;
					break;
				
				case 'A': 
					sommaPari = sommaPari + 0;
					break;
					
				case 'B': 
					sommaPari = sommaPari + 1;
					break;
					
				case 'C':
					sommaPari = sommaPari + 2;
					break;
					
				case 'D': 
					sommaPari = sommaPari + 3;
					break;
					
				case 'E': 
					sommaPari = sommaPari + 4;
					break;
					
				case 'F': 
					sommaPari = sommaPari + 5;
					break;
					
				case 'G': 
					sommaPari = sommaPari + 6;
					break;
					
				case 'H': 
					sommaPari = sommaPari + 7;
					break;
					
				case 'I': 
					sommaPari = sommaPari + 8;
					break;
					
				case 'J': 
					sommaPari = sommaPari + 9;
					break;
					
				case 'K': 
					sommaPari = sommaPari + 10;
					break;
					
				case 'L': 
					sommaPari = sommaPari + 11;
					break;
					
				case 'M': 
					sommaPari = sommaPari + 12;
					break;
					
				case 'N': 
					sommaPari = sommaPari + 13;
					break;
					
				case 'O': 
					sommaPari = sommaPari + 14;
					break;
					
				case 'P':
					sommaPari = sommaPari + 15;
					break;
					
				case 'Q': 
					sommaPari = sommaPari + 16;
					break;
					
				case 'R': 
					sommaPari = sommaPari + 17;
					break;
					
				case 'S': 
					sommaPari = sommaPari + 18;
					break;
					
				case 'T': 
					sommaPari = sommaPari + 19;
					break;
					
				case 'U': 
					sommaPari = sommaPari + 20;
					break;
					
				case 'V': 
					sommaPari = sommaPari + 21;
					break;
					
				case 'W': 
					sommaPari = sommaPari + 22;
					break;
					
				case 'X': 
					sommaPari = sommaPari + 23;
					break;
			
				case 'Y': 
					sommaPari = sommaPari + 24;
					break;
					
				case 'Z': 
					sommaPari = sommaPari + 25;
					break;
			}
		}
		
		int sommaDispari = 0;
		
		for (int i = 0; i <= 14; i = i + 2) 
		{
			switch (codFis.charAt(i))
			{
				case '0':
					sommaDispari = sommaDispari + 1;
					break;
				
				case '1': 
					sommaDispari = sommaDispari + 0;
					break;
				
				case '2': 
					sommaDispari = sommaDispari + 5;
					break;
				
				case '3': 
					sommaDispari = sommaDispari + 7;
					break;
				
				case '4': 
					sommaDispari = sommaDispari + 9;
					break;
				
				case '5': 
					sommaDispari = sommaDispari + 13;
					break;
				
				case '6': 
					sommaDispari = sommaDispari + 15;
					break;
					
				case '7': 
					sommaDispari = sommaDispari + 17;
					break;
					
				case '8': 
					sommaDispari = sommaDispari + 19;
					break;
					
				case '9': 
					sommaDispari = sommaDispari + 21;
					break;
				
				case 'A': 
					sommaDispari = sommaDispari + 1;
					break;
					
				case 'B': 
					sommaDispari = sommaDispari + 0;
					break;
					
				case 'C':
					sommaDispari = sommaDispari + 5;
					break;
					
				case 'D': 
					sommaDispari = sommaDispari + 7;
					break;
					
				case 'E': 
					sommaDispari = sommaDispari + 9;
					break;
					
				case 'F': 
					sommaDispari = sommaDispari + 13;
					break;
					
				case 'G': 
					sommaDispari = sommaDispari + 15;
					break;
					
				case 'H': 
					sommaDispari = sommaDispari + 17;
					break;
					
				case 'I': 
					sommaDispari = sommaDispari + 19;
					break;
					
				case 'J': 
					sommaDispari = sommaDispari + 21;
					break;
					
				case 'K': 
					sommaDispari = sommaDispari + 2;
					break;
					
				case 'L': 
					sommaDispari = sommaDispari + 4;
					break;
					
				case 'M': 
					sommaDispari = sommaDispari + 18;
					break;	
				
				case 'N': 
					sommaDispari = sommaDispari + 20;
					break;
					
				case 'O': 
					sommaDispari = sommaDispari + 11;
					break;
					
				case 'P':
					sommaDispari = sommaDispari + 3;
					break;
					
				case 'Q': 
					sommaDispari = sommaDispari + 6;
					break;
					
				case 'R': 
					sommaDispari = sommaDispari + 8;
					break;
					
				case 'S': 
					sommaDispari = sommaDispari + 12;
					break;
					
				case 'T': 
					sommaDispari = sommaDispari + 14;
					break;
					
				case 'U': 
					sommaDispari = sommaDispari + 16;
					break;
					
				case 'V': 
					sommaDispari = sommaDispari + 10;
					break;
					
				case 'W': 
					sommaDispari = sommaDispari + 22;
					break;
					
				case 'X': 
					sommaDispari = sommaDispari + 25;
					break;
			
				case 'Y': 
					sommaDispari = sommaDispari + 24;
					break;
					
				case 'Z': 
					sommaDispari = sommaDispari + 23;
					break;
			}	
		}
	
		int interoControllo = (sommaPari + sommaDispari) % 26;
		
		String carattereControllo = null;
		
		switch (interoControllo) 
		{
			case 0:
				carattereControllo = "A";
				break;
				
			case 1:
				carattereControllo = "B";
				break;
				
			case 2:
				carattereControllo = "C";
				break;
				
			case 3:
				carattereControllo = "D";
				break;
				
			case 4:
				carattereControllo = "E";
				break;
				
			case 5:
				carattereControllo = "F";
				break;
				
			case 6:
				carattereControllo = "G";
				break;
				
			case 7:
				carattereControllo = "H";
				break;
				
			case 8:
				carattereControllo = "I";
				break;
				
			case 9:
				carattereControllo = "J";
				break;
				
			case 10:
				carattereControllo = "K";
				break;
				
			case 11:
				carattereControllo = "L";
				break;
				
			case 12:
				carattereControllo = "M";
				break;
				
			case 13:
				carattereControllo = "N";
				break;
				
			case 14:
				carattereControllo = "O";
				break;
				
			case 15:
				carattereControllo = "P";
				break;
				
			case 16:
				carattereControllo = "Q";
				break;
				
			case 17:
				carattereControllo = "R";
				break;
				
			case 18:
				carattereControllo = "S";
				break;
				
			case 19:
				carattereControllo = "T";
				break;
				
			case 20:
				carattereControllo = "U";
				break;
				
			case 21:
				carattereControllo = "V";
				break;
				
			case 22:
				carattereControllo = "W";
				break;
				
			case 23:
				carattereControllo = "X";
				break;
				
			case 24:
				carattereControllo = "Y";
				break;
				
			case 25:
				carattereControllo = "Z";
				break;
		}
		
		codFis = codFis + carattereControllo;

		
		return codFis;
		
	}
	

	// CONTROLLO FORMATO CODICE FISCALE
	public static boolean wrong (String checkCF) 
	{
		boolean correct = false;
		
		try 
		{
			//converto i caratteri di checkCF in maiuscoli
			checkCF = checkCF.toUpperCase();
			
			//Elenco possibili caratteri presenti nel codice fiscale
			String allCharacters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			String allNumbers = "0123456789";
			String carattereControllo = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			String allMonth = "ABCDEHLMPRST";
			
			 //tabella valori caratteri di ordine pari
			int[] valoriPari = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
	                 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25};
			
			//tabella valori dispari
			int [] valoriDispari =  {1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 2,
	                 4, 18, 20, 11, 3, 6, 8, 12, 14, 16, 10, 22, 25, 24, 23};
			
			//se checkCF � una stringa vuota o se la lunghezza di checkCF � diversa da 16, il codice � errato
			 if (checkCF.length() != 16)
				 correct = false;
			
			 else if (checkCF.length() == 16) 
			 {
				 //controllo posizioni dell'anno e del giorno siano espresse in numero
				if(XmlUtilsInput.goodCodeComune(checkCF.substring(11, 15))) {
				 if (allNumbers.contains(checkCF.substring(6, 7)) && allNumbers.contains(checkCF.substring(7, 8))) 
				 {
					 //IL PROBLEMA � SUL CONTROLLO DELLA POSIZIONE DELL'ANNO, DEL MESE E DEL GIORNO
					 if(allMonth.contains(checkCF.substring(8, 9))) {
						 String temp=checkCF.substring(8, 9);
						  if (allNumbers.contains(checkCF.substring(9, 10)) && allNumbers.contains(checkCF.substring(10, 11))) 
						  {
							  int tempI=Integer.parseInt(checkCF.substring(9, 11));
							 boolean goodDay=false;
							  switch(temp) {
							  case  "A":
								  if((tempI>0 && tempI<32) || ((tempI-40)>0 && (tempI-40)<32))
									  goodDay=true;
								  break;
							  case "B":
								  if((tempI>0 && tempI<29) || ((tempI-40)>0 && (tempI-40)<29))
									  goodDay=true;
								  break;
							  case "C":
								  if((tempI>0 && tempI<32) || ((tempI-40)>0 && (tempI-40)<32))
									  goodDay=true;
								  break;
							  case "D":
								  if((tempI>0 && tempI<31) || ((tempI-40)>0 && (tempI-40)<31))
									  goodDay=true;
								  break;
							  case "E":
								  if((tempI>0 && tempI<32) || ((tempI-40)>0 && (tempI-40)<32))
									  goodDay=true;
								  break;
							  case "H":
								  if((tempI>0 && tempI<31) || ((tempI-40)>0 && (tempI-40)<31))
									  goodDay=true;
								  break;
							  case "L":
								  if((tempI>0 && tempI<32) || ((tempI-40)>0 && (tempI-40)<32))
									  goodDay=true;
								  break;
							  case "M":
								  if((tempI>0 && tempI<32) || ((tempI-40)>0 && (tempI-40)<32))
									  goodDay=true;
								  break;
							  case "P":
								  if((tempI>0 && tempI<31) || ((tempI-40)>0 && (tempI-40)<31))
									  goodDay=true;
								  break;
							  case "R":
								  if((tempI>0 && tempI<32) || ((tempI-40)>0 && (tempI-40)<32))
									  goodDay=true;
								  break;
							  case "S": 
								  if((tempI>0 && tempI<31) || ((tempI-40)>0 && (tempI-40)<31))
									  goodDay=true;
								  break;
							  case "T":
								  if((tempI>0 && tempI<32) || ((tempI-40)>0 && (tempI-40)<32))
									  goodDay=true;
								  break;
							  }
							 if(goodDay) {
							 int somma = 0;
							 String stringControllo=null;
					 
							 //somma valori caratteri posizioni pari
							 for(int i = 1; i <= 13; i = i + 2) 
							 {
								//prelevo il carattere
								String ch = checkCF.substring(i, (i+1));
								int indice;
							
								indice = allCharacters.indexOf(ch);
								
								
								
								
								//aggiungo alla somma totale il valore della cifra corrispondente
								int tempDeb = valoriPari[indice];
								somma = somma + valoriPari[indice];
								
							 }
							 
							 //somma valori caratteri posizioni dispari
							 for (int i = 0; i <= 14; i = i + 2) 
							 {
								//prelevo il carattere
								 String ch = checkCF.substring(i, (i+1));
									int indice=0;
									 
									indice = allCharacters.indexOf(ch);
							 
									
								
								
								
								//aggiungo alla somma totale il valore della cifra corrispondente
								somma = somma + valoriDispari[indice];
							 }
					
							 
							 //Ricavo la lettera di controllo
							 int letteraControllo = (somma % 26);
							
							 switch (letteraControllo) 
								{
									case 0:
										stringControllo = "A";
										break;
										
									case 1:
										stringControllo = "B";
										break;
										
									case 2:
										stringControllo = "C";
										break;
										
									case 3:
										stringControllo = "D";
										break;
										
									case 4:
										stringControllo = "E";
										break;
										
									case 5:
										stringControllo = "F";
										break;
										
									case 6:
										stringControllo = "G";
										break;
										
									case 7:
										stringControllo = "H";
										break;
										
									case 8:
										stringControllo = "I";
										break;
										
									case 9:
										stringControllo = "J";
										break;
										
									case 10:
										stringControllo = "K";
										break;
										
									case 11:
										stringControllo = "L";
										break;
										
									case 12:
										stringControllo = "M";
										break;
										
									case 13:
										stringControllo = "N";
										break;
										
									case 14:
										stringControllo = "O";
										break;
										
									case 15:
										stringControllo = "P";
										break;
										
									case 16:
										stringControllo= "Q";
										break;
										
									case 17:
										stringControllo = "R";
										break;
										
									case 18:
										stringControllo = "S";
										break;
										
									case 19:
										stringControllo = "T";
										break;
										
									case 20:
										stringControllo = "U";
										break;
										
									case 21:
										stringControllo = "V";
										break;
										
									case 22:
										stringControllo = "W";
										break;
										
									case 23:
										stringControllo = "X";
										break;
										
									case 24:
										stringControllo = "Y";
										break;
										
									case 25:
										stringControllo = "Z";
										break;
								}
							
							 //verifico che sia tra i possibili caratteri di controllo
							 for (int i = 0; i < carattereControllo.length(); i++) 
							 {
								 if(stringControllo.equalsIgnoreCase(carattereControllo.substring(i, (i+1)))) 
								 {
									 //letteraControllo � presente nella stringa carattereControllo
									 
									 i = carattereControllo.length();
								 }
									 
							 }
				 
							 // verifico che letteraControllo coincida con l'ultimo carattere presente in checkCF
							 if (checkCF.substring(15).equalsIgnoreCase(stringControllo)) {
		
								 if(carattereControllo.contains(checkCF.substring(0, 1))) {
									 if(carattereControllo.contains(checkCF.substring(1,2))) {
										 if(carattereControllo.contains(checkCF.substring(2, 3)))
											 {
											 if(carattereControllo.contains(checkCF.substring(3, 4))) {
												 if(carattereControllo.contains(checkCF.substring(4,5))) {
													 if(carattereControllo.contains(checkCF.substring(5,6))) {
														 correct=true;
													 }
												 }
											 }
											 }
									 }
									
								 }
							 }
						  }
						  }
					 }
				 }
			 }
			 else 
				correct = false;
		 }  
		} catch (Exception ex){
			ex.printStackTrace();
			System.out.println("\nInserimento non corretto");
		}
		return correct;
	}
}
